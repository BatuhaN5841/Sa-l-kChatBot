from flask import Flask, request, render_template_string
import pandas as pd

app = Flask(__name__)

# Veri setini yükleme
df = pd.read_csv("saglik_veri_seti.csv")

# HTML şablonu
html_code = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sağlık Chatbot</title>
    <link rel="stylesheet" href="static/styles.css">
    <style>
    
 body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  background-color: #e6efff;
}

header {
  background-color: #77a9ff;
  padding: 15px;
  display: flex;
  align-items: center; /* İçerikleri dikeyde ortalar */
  border-bottom: 1px solid #ddd;
  border-bottom-left-radius: 15px;
  border-bottom-right-radius: 15px;
  position: relative;
}

.header-content {
  display: flex;
  align-items: center;
  width: 100%;
  position: relative; /* Position relative for centering h1 */
  height: 40px;
}

.header-content .logo-container {
  display: flex;
  align-items: center;
  position: absolute; /* Position absolute to keep logos on the left */
  left: 0;
}

.header-content h1 {
  padding: 0;
  text-align: right;
  flex: 1;
  height: 40px;
  font-family: serıf;
}

.header-content a {
  text-decoration: none;
  color: #007bff;
  margin-right: 20px;
}

.logo {
  height: 40px;
  margin-right: 20px;
}

.logom {
  text-align: right;
  height: 40px;
}

main {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 20px;
}

.search-section {
  display: flex;
  align-items: center;
  width: 800px;
  margin-bottom: 20px;
}

#search-input {
  padding: 10px;
  font-size: 16px;
  border: 1px solid #ddd;
  border-radius: 4px;
  flex: 1;
  margin-left: 0.55px;
  box-sizing: border-box; /* İçerik ve kenar boşluklarını dahil et */
  width: 730px;
  border-color: #77a9ff;
  
}

.searchbutton { 
  padding: 10px 20px;
  font-size: 16px;
  background-color: #f9f9f9;
  border: 1px solid #77a9ff;
  border-radius: 4px;
  cursor: pointer;
  width: 65px;
  height: 40px;
  color: black;
  
}
.searchbutton:hover {
  padding: 2px;
}


#results {
  width: 100%;
  max-width: 800px;
  padding: 10px;
  font-size: 16px;
  border: 1px solid #ddd;
  border-radius: 4px;
  background-color: #f9f9f9;
  box-sizing: border-box; /* İçerik ve kenar boşluklarını dahil et */
  font-color: black;
  border-color: #77a9ff;
}

footer {
  background-color: #77a9ff;
  padding: 20px;
  border-top: 1px solid #ddd;
  display: flex;
  justify-content: space-between;
}

footer a {
  text-decoration: none;
  color: #007bff;
}


a.kaynak {
  color: black;
  margin-bottom: 15px;
}

.kaynak:hover {
  padding: 2px;
}
.logok {
  height: 30px;
}

    </style>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sağlık Chatbot</title>
    <link rel="stylesheet" href="{{ url_for('static', filename='styles.css') }}">
</head>
<body>
    <header>
        <div class="header-content">
            <a href="https://github.com/BatuhaN5841">
                <img src="{{ url_for('static', filename='pngimg.com - github_PNG23.png') }}" class="logo">
            </a>
            <img src="{{ url_for('static', filename='eternallogo1.png') }}" class="logom">
            <h1>Sağlık Chatbot</h1>
        </div>
    </header>

    <main class="arka"
    >
        <div class="search-section">
            <form method="POST">
                <input type="text" id="search-input" name="user_input" placeholder="Arama yapın...">
                <button type="submit" class="searchbutton">Ara</button>
            </form>
        </div>
        <div id="results">
            {% if response %}
                <ul>
                    {% for item in response %}
                        <li>{{ item }}</li>
                    {% endfor %}
                </ul>
            {% else %}
                Sonuçlarınız burada gözükecek
            {% endif %}
        </div>
    </main>

    <footer>
        <div class="sources">
            <a href="https://www.saglik.gov.tr/" class="kaynak">
             <img src="{{ url_for('static', filename='pngegg.png') }}" class="logok">
            Kaynakça
            </a>
        </div>
    </footer>
</body>
</html>
"""

# Chatbot işlevi
def chatbot_response(user_input):
    user_input = user_input.strip().lower()
    
    # Hastalık adı ile eşleştirme
    matched_row = df[df['Hastalık Adı'].str.lower() == user_input]
    
    if not matched_row.empty:
        response = [
            f"Hastalık: {matched_row.iloc[0]['Hastalık Adı']}",
            f"Belirtiler: {matched_row.iloc[0]['Belirtiler']}",
            f"Tedavi: {matched_row.iloc[0]['Tedavi']}",
            f"İlaçlar: {matched_row.iloc[0]['İlaçlar']}",
            f"Açıklama: {matched_row.iloc[0]['Açıklama']}",
        ]
    else:
        response = ["Üzgünüm, bu hastalık hakkında bilgiye sahip değilim."]
    
    return response

@app.route("/", methods=["GET", "POST"])
def home():
    response = []
    if request.method == "POST":
        user_input = request.form.get("user_input")
        if user_input:
            response = chatbot_response(user_input)
    return render_template_string(html_code, response=response)

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5001, debug=True)
