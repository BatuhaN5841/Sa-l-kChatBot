from flask import Flask, request, render_template_string
import pandas as pd

app = Flask(__name__)

# Veri setini yükleme
df = pd.read_csv("saglik_veri_seti.csv")

# HTML şablonu
html_code = """
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eternal Sağlık Chatbotu</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            margin-top: 50px;
        }
        .chat-container {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            display: inline-block;
        }
        .chat-container input {
            width: 80%;
            padding: 10px;
            margin: 10px 0;
        }
        .chat-container button {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .chat-container button:hover {
            background-color: #0056b3;
        }
        .response {
            margin-top: 20px;
            font-size: 18px;
            color: #333;
            text-align: left;
        }
        .response p {
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <div class="chat-container">
        <h1>Eternal Sağlık Chatbotu</h1>
        <form method="POST">
            <input type="text" name="user_input" placeholder="Bir hastalık adı yazın...">
            <button type="submit">Gönder</button>
        </form>
        {% if response %}
            <div class="response">
                {% for line in response %}
                    <p>{{ line }}</p>
                {% endfor %}
            </div>
        {% endif %}
    </div>
</body>
</html>
"""

# Chatbot işlevi
def chatbot_response(user_input):
    user_input = user_input.strip().lower()
    
    # Hastalık adı ile eşleştirme
    matched_row = df[df['Hastalık Adı'].str.lower() == user_input]
    
    if not matched_row.empty:
        response = [
            f"Hastalık: {matched_row.iloc[0]['Hastalık Adı']}",
            f"Belirtiler: {matched_row.iloc[0]['Belirtiler']}",
            f"Tedavi: {matched_row.iloc[0]['Tedavi']}",
            f"İlaçlar: {matched_row.iloc[0]['İlaçlar']}",
            f"Açıklama: {matched_row.iloc[0]['Açıklama']}",
        ]
    else:
        response = ["Üzgünüm, bu hastalık hakkında bilgiye sahip değilim."]
    
    return response

@app.route("/", methods=["GET", "POST"])
def home():
    response = []
    if request.method == "POST":
        user_input = request.form["user_input"]
        response = chatbot_response(user_input)
    return render_template_string(html_code, response=response)

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5001, debug=True)
